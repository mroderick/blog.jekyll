# Challenge

This is a solution for the [Ecosia backend assignment](https://gist.github.com/iliasbartolini/465542f9ad3971d3c19ad8541c123e6c).

## How to verify the solution

1. `node index.js`
1. `http http://127.0.0.1:8000/`
1. Observe that the response body is `Please tell me your favorite tree`
1. `http http://127.0.0.1:8000/?favoriteTree=baobab`
1. Observe that the response is `It's nice to know that your favorite tree is a baobab`
