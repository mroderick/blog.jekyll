"use strict";

// import the URL module, so we can use the `URL` constructor
require('url');

/**
 * Request handler for the server
 *
 * @param  {object} req
 * @param  {object} res
 * @returns {undefined}
 */
function handleRequest(req, res) {
  const treeName = getTreeName(req.url);
  const html = treeName
    ? `It's nice to know that your favorite tree is a ${treeName}`
    : "Please tell me your favorite tree";

  res.writeHead(200, {'Content-Type': 'text/html'});
  res.write(html);
  res.end();
}

/**
 * Returns the value of the `favoriteTree` search param
 *
 * @param  {string} url
 * @returns {string|null}
 */
function getTreeName(url) {
  const u = new URL(url, "http://localhost");

  return u.searchParams.get("favoriteTree");
}

module.exports = handleRequest;
