"use strict";

const http = require("http");
const port = process.env.CHALLENGE_PORT || 8000;
const handleRequest = require("./handle-request");
const server = http.createServer(handleRequest);

server.listen(port, serverStartedHandler);

function serverStartedHandler(error) {
  if (error) {
    console.error(error);
    return;
  }

  console.log(`Listening on port: ${port}`);
}
